package com.siv.controllers;

import javax.ws.rs.POST;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;

import org.springframework.beans.factory.annotation.Autowired;

import com.siv.model.User;
import com.siv.repository.UserRepository;

@Path("/user")
public class UserController {
	
	@Autowired
	UserRepository userRepository;
	
	@POST
	@Produces("application/json")
	public User create() {
		/*User user = new User();
		user.setName("Tony");
		user.setUsername("tonyacunar@gmail.com");
		repo.save(user);*/
		
		User user= userRepository.findOne("5850f0eeb6fec727aec14e63");
		
		return user;
	}

}
