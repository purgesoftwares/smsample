package com.siv.controllers;

import javax.ws.rs.GET;
import javax.ws.rs.Path;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;

import org.glassfish.jersey.server.mvc.Template;
import org.glassfish.jersey.server.mvc.Viewable;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

@Path("/login")
@Component
public class PageController {
	
	@GET
	@Produces(MediaType.TEXT_HTML)
	@Path("/me")
	public Viewable welcome() {
		
		return new Viewable("welcome",this);
	
	}

	@GET
	@Produces(MediaType.TEXT_HTML)
	@Template(name="welcome")
	public String welcome1() {
		
		return "welcome";
	
	}

}
